import React from 'react';
import Button from '../common/Button';
import heroImage from '../../assets/hero.jpg';

const Hero = () => {
  return (
    <section id="home" className="relative h-screen flex items-center justify-center text-white">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        {/* Overlay for better text readability */}
        <div className="absolute inset-0 bg-black opacity-50"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center max-w-4xl px-4">
        <h1 className="text-5xl md:text-7xl font-extrabold leading-tight mb-6">
          Explore the World, Seamlessly Connected
        </h1>
        <p className="text-xl md:text-2xl font-light mb-10">
          Your trusted B2B platform for seamless tourism service management, connecting you to hotels, transportation, and local guides worldwide.
        </p>
        <div className="flex justify-center space-x-4">
          <Button className="bg-teal-600 hover:bg-teal-700 text-white border-none">
            Explore Services
          </Button>
          <Button className="bg-transparent hover:bg-white hover:bg-opacity-20 text-white border border-white">
            Join as Partner
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Hero;
