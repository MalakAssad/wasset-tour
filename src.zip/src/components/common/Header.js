import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Button from './Button';
import { FaGlobe } from 'react-icons/fa';

const navItems = [
  { name: 'Home', path: '/' },
  { name: 'About', path: '/about' },
  { name: 'Services', path: '/services' },
  { name: 'Contact', path: '/contact' },
];

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white shadow-md">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center h-16">
        {/* Logo */}
        <Link to="/" className="flex items-center text-2xl font-bold text-teal-600">
          <FaGlobe className="mr-2" />
          Travel.Agency
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8">
          {navItems.map((item) => (
            <Link
              key={item.name}
              to={item.path}
              className="text-gray-600 hover:text-[#F7941D] transition duration-150 ease-in-out font-medium"
            >
              {item.name}
            </Link>
          ))}
        </nav>

        {/* Desktop Button */}
        <Button primary className="hidden md:block">
          Join as Partner
        </Button>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden text-gray-600 hover:text-teal-600"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
          </svg>
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white shadow-md">
          <nav className="flex flex-col space-y-4 px-4 py-6">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className="text-gray-700 hover:text-[#F7941D] font-medium"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
            <Button primary className="w-full">
              Join as Partner
            </Button>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
