import React from 'react';
import Header from '../components/common/Header';
import Footer from '../components/common/Footer';
import Services from '../components/sections/Services';
import Features from '../components/sections/Features'; // Reusing Features for "Why Choose Our Services"
import CTA from '../components/sections/CTA';
import useScrollToTop from '../hooks/useScrollToTop';

const ServicesPage = () => {
  useScrollToTop();

  return (
    <div className="relative">
      <Header />
      <main className="pt-16 min-h-screen">
        {/* Section 1: Hero/Title Section - Matching the image's dark header */}
        <section className="bg-teal-800 text-white py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-5xl font-bold mb-2">Our Services</h1>
            <p className="text-xl font-light max-w-3xl mx-auto">
              Comprehensive tourism services connecting you with the best providers.
            </p>
          </div>
        </section>
        
        {/* Section 2: Main Services List - Using the new, image-matched Services component */}
        <Services />

        {/* Section 3: Why Choose Our Services - Reusing the Features component and renaming the title */}
        <Features title="Why Choose Our Services" subtitle="We guarantee quality, reliability, and the best prices for your clients." />

        {/* Section 4: Ready to Get Started CTA - Matching the image's dark footer CTA */}
        <CTA />
      </main>
      <Footer />
    </div>
  );
};

export default ServicesPage;
